using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ErrorPress1 : MonoBehaviour
{
    private int errorClick;
    void Start()
    {
        errorClick = 1;
    }

    void Update()
    {
        StartCoroutine("Delay");
        LifeDecrease();
    }
    // Set errorclik equal to 0 when a collision occurs
    private void OnTriggerEnter(Collider other)
    {
        errorClick = 0;
    }
    // Decreases the score and increases the count of wrong movements when the object created by comndo does not collide with any keys
    private void LifeDecrease()
    {
        StartCoroutine("Delay");
        if (errorClick == 1)
        {
            errorClick = 0;
            GameManager1.Instance.Score--;
            GameManager1.Instance.Wrong++;
        }
    }

    IEnumerator Delay()
    {
        yield return new WaitForSeconds(0.3f);
    }
}
