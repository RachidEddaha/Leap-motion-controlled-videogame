using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FingerPress1 : MonoBehaviour
{
    public GameObject keys;
    private int points = 3;

    public Material correct;
    private Renderer rend;

    private void Start()
    {
        rend = keys.GetComponent<Renderer>();
    }
    //Increases the score and count of correct movements when the gameObject generate from command collides with a key and the key material changes to correct material
    private void OnTriggerEnter(Collider other)
    {
        if (rend.sharedMaterial != correct)
        {
            rend.material = correct; //change material
            Destroy(other.gameObject);
            GameManager1.Instance.Score += points;
            GameManager1.Instance.Right++;
        }     
    }
}
