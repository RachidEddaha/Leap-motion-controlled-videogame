using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeysMovement1 : MonoBehaviour
{
    private float speed0 = 4.0f;
    private float speed1 = 5.0f;
    private float speed2 = 6.0f;
    private float speed3 = 7.0f;
    private float speed4 = 8.0f;

    private int level1 = 30;
    private int level2 = 60;
    private int level3 = 90;
    private int level4 = 120;



    // For each level you set the speed of the keys
    void Update()
    {
        
        if (GameManager1.Instance.Score <= level1 && !GameManager1.Pause.Equals(1))
        {
            transform.Translate(Vector3.back * speed0 * Time.deltaTime);
        }
        else if (GameManager1.Instance.Score <= level2 && !GameManager1.Pause.Equals(1))
        {
            transform.Translate(Vector3.back * speed1 * Time.deltaTime);
        }
        else if (GameManager1.Instance.Score <= level3 && !GameManager1.Pause.Equals(1))
        {
            transform.Translate(Vector3.back * speed2 * Time.deltaTime);
        }
        else if (GameManager1.Instance.Score <= level4 && !GameManager1.Pause.Equals(1))
        {
            transform.Translate(Vector3.back * speed3 * Time.deltaTime);
        }
        else if ( !GameManager1.Pause.Equals(1))
        {
            transform.Translate(Vector3.back * speed4 * Time.deltaTime);
        }

       

    }
}
