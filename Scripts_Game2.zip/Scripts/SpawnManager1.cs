using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager1 : MonoBehaviour
{

    public GameObject fingerPrefab;

    private GameObject fingerThumb;
    private GameObject fingerIndex;
    private GameObject fingerMiddle;
    private GameObject fingerRing;
    private GameObject fingerPinkie;

    private float spawnThumbX = -78.3f;
    private float spawnIndexX = -64.15f;
    private float spawnMiddleX = -50.0f;
    private float spawnRingX = -35.85f;
    private float spawnPinkieX = -21.7f;

    private float spawnFingerZ = -16.0f;
    private float spawnFingerY = -1.5f;
    private float timeFinger = 0.4f;



    // Calls up the functions below when the keys F1,F2,F3,F4,F5 are pressed. These commands are no longer used in the game because they are now controlled by leap motion, which was not available before.
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F1))
        {
            DestroyThumb();
        }

        if (Input.GetKeyDown(KeyCode.F2))
        {
            DestroyIndex();
        }

        if (Input.GetKeyDown(KeyCode.F3))
        {
            DestroyMiddle();
        }

        if (Input.GetKeyDown(KeyCode.F4))
        {
            DestroyRing();
        }

        if (Input.GetKeyDown(KeyCode.F5))
        {
            DestroyPinkie();
        }
    }

    // instantiate the gameObject in the correct thumb position
    public void DestroyThumb()
    {
        Vector3 spawnPos = new Vector3(spawnThumbX, spawnFingerY, spawnFingerZ);
        fingerThumb = Instantiate(fingerPrefab, spawnPos, fingerPrefab.transform.rotation);
        Object.Destroy(fingerThumb, timeFinger);
    }
    // instantiate the gameObject in the correct index finger position
    public void DestroyIndex()
    {
        Vector3 spawnPos = new Vector3(spawnIndexX, spawnFingerY, spawnFingerZ);
        fingerIndex = Instantiate(fingerPrefab, spawnPos, fingerPrefab.transform.rotation);
        Object.Destroy(fingerIndex, timeFinger);
    }
    // instantiate the gameObject in the correct middle finger position
    public void DestroyMiddle()
    {
        Vector3 spawnPos = new Vector3(spawnMiddleX, spawnFingerY, spawnFingerZ);
        fingerMiddle = Instantiate(fingerPrefab, spawnPos, fingerPrefab.transform.rotation);
        Object.Destroy(fingerMiddle, timeFinger);
    }
    // instantiate the gameObject in the correct ring finger position
    public void DestroyRing()
    {
        Vector3 spawnPos = new Vector3(spawnRingX, spawnFingerY, spawnFingerZ);
        fingerRing = Instantiate(fingerPrefab, spawnPos, fingerPrefab.transform.rotation);
        Object.Destroy(fingerRing, timeFinger);
    }
    // instantiate the gameObject in the correct pinkie finger position
    public void DestroyPinkie()
    {
        Vector3 spawnPos = new Vector3(spawnPinkieX, spawnFingerY, spawnFingerZ);
        fingerPinkie = Instantiate(fingerPrefab, spawnPos, fingerPrefab.transform.rotation);
        Object.Destroy(fingerPinkie, timeFinger);
    }
}
