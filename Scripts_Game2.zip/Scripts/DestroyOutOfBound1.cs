using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOutOfBound1 : MonoBehaviour
{
    private float botBound = -28.0f;

    public GameObject keysCorrect;
    public Material correct;
    private Renderer rend;

    void Start()
    {
        rend = GetComponent<Renderer>();
    }
    //Destroys the keys when its position exceeds botBound, if the keys has material other than correct material the life is decreased and the count of incorrect movements is increased
    void Update()
    {
        if (transform.position.z < botBound)
        {

            if (rend.sharedMaterial != correct)
            {
                GameManager1.Instance.Life--; //Decrease life
                if (GameManager1.Instance.Life > 0)
                {
                    GameManager1.Instance.Wrong++; //Increase Wrong movement
                }
                
            }
            Destroy(gameObject);
        }
    }
}
