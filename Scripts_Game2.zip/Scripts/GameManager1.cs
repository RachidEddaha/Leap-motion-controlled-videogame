using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Leap.Unity;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;


public class GameManager1 : MonoBehaviour
{
    private int level1 = 30;
    private int level2 = 60;
    private int level3 = 90;
    private int level4 = 120;

    private int difficulty;

    public HandModelBase hand = null;
    public GameObject[] keysPrefabs;
    public GameObject[] pauseScene;
    public GameObject[] LeapNopauseScene;

    private float spawnThumbX = -78.3f;
    private float spawnIndexX = -64.15f;
    private float spawnMiddleX = -50.0f;
    private float spawnRingX = -35.85f;
    private float spawnPinkieX = -21.7f;
    private float spawnKeysZ = 28.0f;

    private float startDelay = 1.5f;
    private int condition;

    private Keys keysIndex;
    private Keys keysOld;

    public GameObject panelMenu;
    public GameObject panelPlay;
    public GameObject panelGameOver;
    public GameObject panelSetting;
    public GameObject panelPause;
    public GameObject panelInstructions;

    public GameObject textCongratulation;

    public GameObject soundtrack;
    public AudioMixer audioMixerr;

    public Text textScore;
    public Text textLife;
    public Text textHighscore;
    public Text textFinalScore;

    public Text textWrong;
    public Text textRight;
    public Text textSensibility;

    public static GameManager1 Instance { get; private set; }

    // Create the states variables
    public enum State { MENU, INIT, PLAY, GAMEOVER, PAUSE }
    private State state;

    private bool isSwitchingState;
    //Create variables and a public function to be able to modify them from other scripts
    private int score;
    public int Score
    {
        get { return score; }
        set
        {
            score = value;
            textScore.text = "SCORE:" + score;
        }
    }

    private int numberLife = 3;
    private int life;
    public int Life
    {
        get { return life; }
        set
        {
            life = value;
            textLife.text = "LIFE:" + life;
        }
    }

    private int wrong;
    public int Wrong
    {
        get { return wrong; }
        set
        {
            wrong = value;
            textWrong.text = "WRONG MOVEMENT: " + wrong;
        }
    }

    private int right;
    public int Right
    {
        get { return right; }
        set
        {
            right = value;
            textRight.text = "CORRECT MOVEMENT: " + right;
        }
    }



    private static int pause = 0;
    public static int Pause
    {
        get { return pause; }
        set
        {
            pause = value;
        }
    }

    private static int sensibility = 30;
    public static int Sensibility
    {
        get { return sensibility; }
        set
        {
            sensibility = value;
        }
    }
    //Set the sensitivity
    public void setSensibility (float sensibilityy)
    {
        Sensibility = Mathf.RoundToInt(sensibilityy*100);
        textSensibility.text = "SENSITIVITY: " + Sensibility + " %";
        PlayerPrefs.SetFloat("SensibilityGame1", sensibilityy);
    }
    // Function to be assigned to a button to return to scene 0
    public void QuitPause()
    {
        SceneManager.LoadScene(0);
    }
    // Function to be assigned to a button to return to scene 0
    public void QuitMenu()
    {
        SceneManager.LoadScene(0);
    }
    // Function to be assigned to a button to enter in panelInstructions
    public void Instructions()
    {
        panelInstructions.SetActive(true);
        panelMenu.SetActive(false);
    }
    // Function to be assigned to a button to return in the menu of the game from panelInstructions
    public void BackInstructions()
    {
        panelInstructions.SetActive(false);
        panelMenu.SetActive(true);
    }
    // Function to be assigned to a button to set difficulty easy
    public void Easy()
    {
        SwitchState(State.INIT);
        difficulty = 0;
    }
    // Function to be assigned to a button to set difficulty medium
    public void Medium()
    {
        SwitchState(State.INIT);
        difficulty = 1;
    }
    // Function to be assigned to a button to set difficulty hard
    public void Hard()
    {
        SwitchState(State.INIT);
        difficulty = 2;
    }
    // Function to be assigned to a button to return in the game from panelPause
    public void Resume()
    {
        Pause = 0;
    }
    // Function to be assigned to a button to enter in panelSettings
    public void Option()
    {
        int f = 0;
        for (f = 0; f < pauseScene.Length; f++)
        {
            pauseScene[f].SetActive(false);
        }
        panelSetting.SetActive(true);
        panelPause.SetActive(false);
    }
    // Function to be assigned to a button to return in the in panelPause from panelSettings
    public void Back()
    {
        panelSetting.SetActive(false);
        panelPause.SetActive(true);
        int f = 0;
        for (f = 0; f < pauseScene.Length; f++)
        {
            pauseScene[f].SetActive(true);
        }
    }
    // Function to set the volume during the game
    public void SetVolume(float volume)
    {
        volume = (volume) * 80 / (1) - 80;
        audioMixerr.SetFloat("VolumeGame2", volume);
        PlayerPrefs.SetFloat("volumeGame", volume);

    }

    void Start()
    {
        Instance = this;
        Pause = 0;
        int f = 0;
        for (f = 0; f < pauseScene.Length; f++) // put off all the element that i will use in the pause menu 
        {
            pauseScene[f].SetActive(false);
        }
        for (f = 0; f < LeapNopauseScene.Length; f++) // put on all the element that i will use during the game connected to leapmotion
        {
            LeapNopauseScene[f].SetActive(true);
        }
        if (PlayerPrefs.GetFloat("volumeGame").IsBetween(0f, 1f)) // to use the same volume as in the previous game
        {
            SetVolume(PlayerPrefs.GetFloat("volumeGame"));
        }
        else
        {
            SetVolume(0.75f);
        }

        if (PlayerPrefs.GetFloat("SensibilityGame1").IsBetween(0f, 1f)) // to use the same sensitivity as in the previous game
        {
            setSensibility(PlayerPrefs.GetFloat("SensibilityGame1"));

        }
        else
        {
            setSensibility(0.3f);
        }
        SwitchState(State.MENU);
        keysOld = keysIndex;
    }
    // Function to switch between states
    public void SwitchState(State newState, float delay = 0.0f)
    {
        StartCoroutine(SwitchDelay(newState, delay));
    }
    // Function to switch between states
    IEnumerator SwitchDelay(State newState, float delay)
    {
        isSwitchingState = true;
        yield return new WaitForSeconds(delay);
        EndState();
        state = newState;
        BeginState(newState);
        isSwitchingState = false;
    }

    // Things executed when entering a state
    void BeginState(State newState)
    {
        switch (newState)
        {
            case State.MENU:
                panelMenu.SetActive(true);
                textHighscore.text = "HIGHSCORE:" + PlayerPrefs.GetInt("HighscoreGame1");
                textCongratulation.SetActive(false);
                condition = 0;
                break;
            case State.INIT:
                panelPlay.SetActive(true);
                Score = 0;
                Life = numberLife;
                Right = 0;
                Wrong = 0;
                textSensibility.text = "SENSITIVITY: " + Sensibility + " %";
                SwitchState(State.PLAY);
                break;
            case State.PLAY:
                soundtrack.SetActive(true);
                break;
            case State.GAMEOVER:
                soundtrack.SetActive(false);
                CancelInvoke("SpawnKeys");
                Wrong++;
                GameObject[] keys = GameObject.FindGameObjectsWithTag("Piano");
                for (int i = 0; i < keys.Length; i++)
                {
                    Destroy(keys[i]);
                }
                panelGameOver.SetActive(true);
                panelPause.SetActive(true);
                if (Score > PlayerPrefs.GetInt("HighscoreGame1"))
                {
                    PlayerPrefs.SetInt("HighscoreGame1", Score);
                    textCongratulation.SetActive(true);
                }
                textSensibility.text = "SENSITIVITY: " + Sensibility + " %";
                textFinalScore.text = "FINAL SCORE:" + Score;
                SwitchState(State.MENU, 5.0f);
                break;
            case State.PAUSE:
                soundtrack.SetActive(false);
                CancelInvoke("SpawnKeys");
                Pause = 1;
                int f = 0;
                for (f = 0; f < LeapNopauseScene.Length; f++)
                {
                    LeapNopauseScene[f].SetActive(false);
                }
                for (f = 0; f < pauseScene.Length; f++)
                {
                    pauseScene[f].SetActive(true);
                }
                panelPause.SetActive(true);
                break;
        }
    }

    void Update()
    {
        switch (state)
        {
            case State.MENU:
                break;
            case State.INIT:
                break;
            case State.PLAY:
                if (!hand.IsTracked) //If the hand is not detected, pause the game.
                {
                    SwitchState(State.PAUSE);
                    break;
                }
                
                if (Life <= 0)
                {
                    SwitchState(State.GAMEOVER);
                    CancelInvoke("SpawnKeys");
                }

                if (Score <= level1 && condition == 0) //for each level and difficulty resets the invokeRepeting because the speed and the dimensions of the keys change
                {
                    if (difficulty == 0)
                    {
                        condition++;
                        InvokeRepeating("SpawnKeys", startDelay, 3.5f);
                    }
                    if (difficulty == 1)
                    {
                        condition++;
                        InvokeRepeating("SpawnKeys", startDelay, 2.5f);
                    }
                    if (difficulty == 2)
                    {
                        condition++;
                        InvokeRepeating("SpawnKeys", startDelay, 1.5f);
                    }
                }
                if (Score > level1 && condition == 1)
                {
                    if (difficulty == 0)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.2f, 2.8f);
                    }
                    if (difficulty == 1)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.225f, 2.0f);
                    }
                    if (difficulty == 2)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.25f, 1.2f);
                    }
                }
                if (Score > level2 && condition == 2)
                {
                    if (difficulty == 0)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.2f, 2.33333f);
                    }
                    if (difficulty == 1)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.225f, 1.66667f);
                    }
                    if (difficulty == 2)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.25f, 1.0f);
                    }
                }
                if (Score > level3 && condition == 3)
                {
                    if (difficulty == 0)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.2f, 2f);
                    }
                    if (difficulty == 1)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.225f, 1.42857f);
                    }
                    if (difficulty == 2)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.25f, 0.85714f);
                    }
                }
                if (Score > level4 && condition == 4)
                {
                    if (difficulty == 0)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.2f, 1.75f);
                    }
                    if (difficulty == 1)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.225f, 1.25f);
                    }
                    if (difficulty == 2)
                    {
                        condition++;
                        CancelInvoke("SpawnKeys");
                        InvokeRepeating("SpawnKeys", 0.25f, 0.75f);
                    }
                }
                break;
            case State.GAMEOVER:
                break;
            case State.PAUSE:
                if (pause.Equals(0))
                {
                    SwitchState(State.PLAY);
                }
                break;
        }
    }

    // Things done when exiting a state
    void EndState()
    {
        switch (state)
        {
            case State.MENU:
                panelMenu.SetActive(false);
                break;
            case State.INIT:
                break;
            case State.PLAY:
                break;
            case State.GAMEOVER:
                panelPlay.SetActive(false);
                panelGameOver.SetActive(false);
                panelPause.SetActive(false);
                break;
            case State.PAUSE:
                int i = 0;
                for (i = 0; i < pauseScene.Length; i++)
                {
                    pauseScene[i].SetActive(false);
                }
                int f = 0;
                for (f = 0; f < LeapNopauseScene.Length; f++)
                {
                    LeapNopauseScene[f].SetActive(true);
                }

                if (Score <= level1) condition = 0;
                if (Score > level1 && Score <= level2) condition = 1;
                if (Score > level2 && Score <= level3) condition = 2;
                if (Score > level3 && Score <= level4) condition = 3;
                if (Score > level4 ) condition = 4;
                soundtrack.SetActive(true);
                panelPause.SetActive(false);
                break;
        }
    }

    // Create the Keys variables
    public enum Keys { Thumb, Index, Middle, Ring, Pinkie }
    //Instantiate the keys in a Random position
    void SpawnKeys()
    {
        keysIndex = (Keys)Random.Range(0, 5);
        if (keysIndex != keysOld)
        {
            keysOld = keysIndex;
            switch (keysIndex)
            {
                case Keys.Thumb:
                    Vector3 spawnThumb = new Vector3(spawnThumbX, 0, spawnKeysZ);
                    Instantiate(keysPrefabs[difficulty], spawnThumb, keysPrefabs[difficulty].transform.rotation);
                    break;
                case Keys.Index:
                    Vector3 spawnIndex = new Vector3(spawnIndexX, 0, spawnKeysZ);
                    Instantiate(keysPrefabs[difficulty], spawnIndex, keysPrefabs[difficulty].transform.rotation);
                    break;
                case Keys.Middle:
                    Vector3 spawnMiddle = new Vector3(spawnMiddleX, 0, spawnKeysZ);
                    Instantiate(keysPrefabs[difficulty], spawnMiddle, keysPrefabs[difficulty].transform.rotation);
                    break;
                case Keys.Ring:
                    Vector3 spawnRing = new Vector3(spawnRingX, 0, spawnKeysZ);
                    Instantiate(keysPrefabs[difficulty], spawnRing, keysPrefabs[difficulty].transform.rotation);
                    break;
                case Keys.Pinkie:
                    Vector3 spawnPinkie = new Vector3(spawnPinkieX, 0, spawnKeysZ);
                    Instantiate(keysPrefabs[difficulty], spawnPinkie, keysPrefabs[difficulty].transform.rotation);
                    break;
            }
        }

    }
}
