using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gameManagerMenu : MonoBehaviour
{
    public GameObject backGround1;
    public GameObject backGround2;
    public GameObject backGround3;

    public void ChangeGame(float choice)
    {
        if (choice == 1)
        {
            backGround1.SetActive(true);
            backGround2.SetActive(false);
            backGround3.SetActive(false);
        }
        if (choice == 2)
        {
            backGround2.SetActive(true);
            backGround1.SetActive(false);
            backGround3.SetActive(false);
        }
        if (choice == 3)
        {
            backGround3.SetActive(true);
            backGround2.SetActive(false);
            backGround1.SetActive(false);
        }
    }

}
