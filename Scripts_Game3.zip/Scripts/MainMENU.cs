 using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity;

public class MainMENU : MonoBehaviour
{

    public HandModelBase hand=null;

    
    public void QuitGame()
    {
        Debug.Log("quit");
    }
    public void Play()
    {
        GameManager.Pause = 0;
    }

    public void Options()
    {
        
    }
}
