using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class gameManagerMenu2 : MonoBehaviour
{
    public GameObject backGround1;
    public GameObject backGround2;
    public GameObject backGround3;
    public GameObject palmOrientation;
    private int unloadd = 0;

    void Awake() // we set our sensitivity
    {
        PlayerPrefs.SetFloat("SensibilityGame1", 0.3f);
        PlayerPrefs.SetFloat("SensibilityGame2", 0.3f);
        PlayerPrefs.SetFloat("SensibilityGame3", 0.3f);
        PlayerPrefs.SetFloat("volumeGame", 0.75f);
        /*GameManager.Instance.Setsensibility( 0.3f);        
        GameManager1.Instance.setSensibility(0.3f);
        GameManager3.Instance.Setsensibility(0.3f);*/
        GameManager.Sensibility=30;
        GameManager1.Sensibility = 30;
        GameManager3.Sensibility = 30;
    }


    private int choices = 1;
 
    public void PlayGame() // if the play is pressed both by the buttor or by the movement of the index we select the game
    {
        if (choices == 1) SceneManager.LoadScene(1);
        if (choices == 2) SceneManager.LoadScene(2);
        if (choices == 3) SceneManager.LoadScene(3);
    }

    public void Quitt() // to close the application
    {
        Debug.Log("quit");
        Application.Quit();

    }

    public void ChangeGameSlider(float choice)// to change the background so, one knows wich game is choising here by the slidere that is place up the start buttor
    {
        
        choices = (int) choice;
        if (choice == 1)
        {
            backGround1.SetActive(true);
            backGround2.SetActive(false);
            backGround3.SetActive(false);
        }
        if (choice == 2)
        {
            backGround2.SetActive(true);
            backGround1.SetActive(false);
            backGround3.SetActive(false);
        }
        if (choice == 3)
        {
            backGround3.SetActive(true);
            backGround2.SetActive(false);
            backGround1.SetActive(false);
        }
    }
    public void  ChangeGame(int choice) // and here by the swing of the hand 
    {
        
        choices = choice;
        if (choice == 1)
        {
            backGround1.SetActive(true);
            backGround2.SetActive(false);
            backGround3.SetActive(false);
        }
        if (choice == 2)
        {
            backGround2.SetActive(true);
            backGround1.SetActive(false);
            backGround3.SetActive(false);
        }
        if (choice == 3)
        {
            backGround3.SetActive(true);
            backGround2.SetActive(false);
            backGround1.SetActive(false);
        }
    }
    
    }