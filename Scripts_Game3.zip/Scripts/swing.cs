using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity;
using Leap;
using Leap.Unity.Attributes;




public class swing : MonoBehaviour
{

    private Pose Abd;
    public Vector3 position;
    public Quaternion orientation;
    public Vector3 inEUler;
    public float value4Controll = 0.0f;
    public float ExtremeValueLeft = -1.2f;
    public float ExtremeValueRight = 1f;
    private float ExtremeValueLeftCalculated = -1.2f;
    private float ExtremeValueRightCalculated = 1f;
    private int choices = 1;
    private int control = 0;
    public GameObject manager;

    [Units("seconds")]
    [Tooltip("The interval in seconds at which to check this detector's conditions.")]
    [MinValue(0)]
    public float Period = .1f; //seconds

    [Tooltip("The hand model to watch. Set automatically if detector is on a hand.")]
    public HandModelBase HandModel = null;

    private IEnumerator watcherCoroutine;

    private void Awake()
    {
        watcherCoroutine = palmWatcher();
        
    }

    private void OnEnable()
    {
        StartCoroutine(watcherCoroutine);
    }

    private void OnDisable()
    {
        StopCoroutine(watcherCoroutine);

    }

    /*this function allows you to adjust the sensitivity with which the movement of the hand is converted
    * into a command for the game by changing the extremes of the ranges of movement.
    * 
    */
    public void SetSensibility(float percentage)
    {
        ExtremeValueLeftCalculated = ExtremeValueLeft * (1 - percentage);
        ExtremeValueRightCalculated = ExtremeValueRight * (1 - percentage);
        print(percentage);
    }



    private IEnumerator palmWatcher()
    {
        Hand hand;
        Vector3 normal;
        SetSensibility(0.8f); // it is only the menu so we setted it high 
        while (true)
        {
            if (HandModel != null)
            {
                hand = HandModel.GetLeapHand();
                if (hand != null)  // if the leapmotion can read the hand 
                {

                    Abd = hand.GetPalmPose();
                    position = Abd.position;
                    orientation = Abd.rotation;
                    inEUler = Quaternion.ToEulerAngles(orientation);

                    /*
                     * as first thing we check that the orientation of the palm is in the correct position,
                     * we set the values of the extremes between -1 and 1.every time it detects the "swing"
                     * the hand must return to the zero position in order to detect another swing.
                     */

                    if (inEUler.z.IsBetween(-2.5f, -0.8f))
                    {
                        float value4Controll_1 = Mathf.Max((inEUler.y - ExtremeValueLeftCalculated) * 2 / (ExtremeValueRightCalculated - ExtremeValueLeftCalculated) - 1, -1);
                        value4Controll = Mathf.Min(value4Controll_1, 1);
                        if (value4Controll == -1f && control != 1)
                        {
                            control = 1;
                            if (choices != 1) choices--;
                        }
                        if (value4Controll > -0.4f && value4Controll < 0.4f && control == 1)
                        {
                            control = 0;
                        }
                        if (value4Controll == 1f && control != 1)
                        {
                            control = 1;
                            if (choices != 3) choices++;
                        }
                        //ChangeGame(choices);
                        manager.GetComponent<gameManagerMenu2>().ChangeGame(choices);
                        


                    }
                    else
                    {
                        value4Controll = 0;

                    }
                }
            }
            yield return new WaitForSeconds(Period);
        }
    }

}
