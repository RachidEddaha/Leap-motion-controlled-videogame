using System.Collections;
using System.Collections.Generic;
using UnityEngine;


using Leap.Unity;
using Leap;
using Leap.Unity.Attributes;


public class PlayerController : MonoBehaviour
{

    private Rigidbody playerRb;
    public float horizontalInput;
    private float speed = 30.0f;
    private float angle = 10.0f;
    public GameObject valueControll ;
    public float controller = 0.0f;
    AudioSource audioo;

    // Start is called before the first frame update
    void Start()
    {
        playerRb = GetComponent<Rigidbody>();
        audioo = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        transform.Translate(Vector3.up * horizontalInput * -speed * Time.deltaTime);
        controller = valueControll.GetComponent<computePalm>().value4Controll;
        Controller(controller);
    }

    private void OnCollisionEnter(Collision coll)
    {
        if (coll.gameObject.tag == "Ball") //When the player collide with ball, the player add a forse in different direction in base at the distance where the ball collide with the player respect to center of the player
        {
            Rigidbody ballRb = coll.gameObject.GetComponent<Rigidbody>();
            Vector3 hitPoint = coll.GetContact(0).point;
            Vector3 paddleCenter = new Vector3(this.gameObject.transform.position.x, this.gameObject.transform.position.y, this.gameObject.transform.position.z);
            float difference = paddleCenter.x - hitPoint.x;

            if (hitPoint.x < paddleCenter.x)
            {
                ballRb.AddForce(new Vector3(-(Mathf.Abs(difference) * angle), angle), ForceMode.Impulse);
            }
            else
            {
                ballRb.AddForce(new Vector3((Mathf.Abs(difference) * angle), angle), ForceMode.Impulse);
            }
            GameManager.Instance.Right++;
            audioo.Play();
        }

        
        

        if (coll.collider.CompareTag("Wall"))
        {
            Rigidbody wallRb = coll.gameObject.GetComponent<Rigidbody>();
            print("contatto avvenuto");
            Vector3 lockedPoint = new Vector3(this.gameObject.transform.position.x, this.gameObject.transform.position.y, this.gameObject.transform.position.z);
            Vector3 positionLocked = new Vector3( lockedPoint.x, playerRb.transform.position.y, playerRb.transform.position.z);
            print(lockedPoint);
            playerRb.MovePosition(positionLocked);
        }
    }


    // Function that positions the paddle on the display in proportion to the distance given as argument
    public void Controller(float distance)
    {       
        float offset = 50.0f;
        float molti = 20.0f;
        if (GameManager.Instance.Offset == 0) { molti = 18.0f; }
        else if (GameManager.Instance.Offset == 3) { molti = 19.0f; }
        else { molti = 20.0f; }
        Vector3 position = new Vector3(-offset + (molti * distance), playerRb.transform.position.y, playerRb.transform.position.z);
        playerRb.MovePosition(position);
    }

    
}
