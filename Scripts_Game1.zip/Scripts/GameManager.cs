using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Leap.Unity;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject PalmOrientation;
    public HandModelBase hand = null;
    public GameObject[] pauseScene;
    public GameObject[] LeapNopauseScene;

    public GameObject[] spherePrefab;
    public GameObject[] playerPrefab;
    public GameObject[] wallPrefab;
    public GameObject[] levels;

    private GameObject currentSphere;
    private GameObject currentPlayer;
    private GameObject currentWall;
    private GameObject currentLevel;
    

    public GameObject panelMenu;
    public GameObject panelPlay;
    public GameObject panelLevelCompleted;
    public GameObject panelGameOver;
    public GameObject panelSetting;
    public GameObject panelPause;
    public GameObject panelInstructions;

    public AudioMixer audioMixerr;

    public GameObject textCongratulation;



    public Text textScore;
    public Text textLife;
    public Text textLevel;
    public Text textHighscore;
    public Text textFinalScore;

    public Text textWrong;
    public Text textRight;
    public Text textSensibility;

    public static GameManager Instance { get; private set; }


    public enum State { MENU, INIT, PLAY, LEVELCOMPLETED, LOADLEVEL, GAMEOVER, PAUSE }
    private State state;
    //Create variables and a public function to be able to modify them from other scripts
    private static int pause=0;
    public static int Pause
    {
        get { return pause; }
        set
        {
            pause = value;
        }
    }

    private bool isSwitchingState;

    private int score;
    public int Score
    {
        get { return score; }
        set
        {
            score = value;
            textScore.text = "SCORE:" + score;
        }
    }

    private int numberLife = 3;
    private int life;
    public int Life
    {
        get { return life; }
        set
        {
            life = value;
            textLife.text = "LIFE:" + life;
        }
    }

    private int level;
    public int Level
    {
        get { return level; }
        set
        {
            level = value;
            textLevel.text = "LEVEL:" + level;
        }
    }

    private int wrong;
    public int Wrong
    {
        get { return wrong; }
        set
        {
            wrong = value;
            textWrong.text = "WRONG MOVEMENT: " + wrong;
        }
    }

    private int right;
    public int Right
    {
        get { return right; }
        set
        {
            right = value;
            textRight.text = "CORRECT MOVEMENT: " + right;
        }
    }

    private static int sensibility = 30;
    public static int Sensibility
    {
        get { return sensibility; }
        set
        {
            sensibility = value;
        }
    }
    //Set the sensitivity
    public void Setsensibility(float percentage)
    {
        Sensibility = Mathf.RoundToInt(percentage * 100);
        textSensibility.text = "SENSITIVITY: " + Sensibility + " %";
        PlayerPrefs.SetFloat("SensibilityGame2", percentage);
    }
    //to set where to start with the index of vectors according to level
    private int offset;
    public int Offset
    {
        get { return offset; }
        set { offset = value; }
    }
    // Function to be assigned to a button to return to scene 0
    public void QuitPause()
    {
        SceneManager.LoadScene(0);
    }
    // Function to be assigned to a button to return to scene 0
    public void QuitMenu()
    {
        SceneManager.LoadScene(0);
    }
    // Function to be assigned to a button to enter in panelInstructions
    public void Instructions()
    {
        panelInstructions.SetActive(true);
        panelMenu.SetActive(false);
    }
    // Function to be assigned to a button to return in the menu of the game from panelInstructions
    public void BackInstructions()
    {
        panelInstructions.SetActive(false);
        panelMenu.SetActive(true);
    }

    // Function to be assigned to a button to set difficulty easy
    public void Easy()
    {
        SwitchState(State.INIT);
        offset = 0;
    }
    // Function to be assigned to a button to set difficulty medium
    public void Medium()
    {
        SwitchState(State.INIT);
        offset = levels.Length;
    }
    // Function to be assigned to a button to set difficulty hard
    public void Hard()
    {
        SwitchState(State.INIT);
        offset = levels.Length * 2;
    }
    // Function to be assigned to a button to return in the game from panelPause
    public void Resume()
    {
        Pause = 0;
    }
    // Function to be assigned to a button to enter in panelSettings
    public void Option()
    {
        int f = 0;
        for (f = 0; f < pauseScene.Length; f++)
        {
            pauseScene[f].SetActive(false);
        }
        panelSetting.SetActive(true);
        panelPause.SetActive(false);
    }
    // Function to be assigned to a button to return in the in panelPause from panelSettings
    public void Back()
    {
        panelSetting.SetActive(false);
        panelPause.SetActive(true);
        int f = 0;
        for (f = 0; f < pauseScene.Length; f++)
        {
            pauseScene[f].SetActive(true);
        }
          }
    // Function to set the volume during the game
    public void SetVolume(float volume)
    {
        volume = (volume ) *80 / (1) - 80;
        audioMixerr.SetFloat("VolumeGame2",volume);
        PlayerPrefs.SetFloat("volumeGame", volume);

    }

    void Start()
    {
        Instance = this;
        Pause = 0;
        int f = 0;
        for (f = 0; f < pauseScene.Length; f++)// put off all the element that i will use in the pause menu 
        {
            pauseScene[f].SetActive(false);
        }
        for (f = 0; f < LeapNopauseScene.Length; f++) // put on all the element that i will use during the game connected to leapmotion
        {
            LeapNopauseScene[f].SetActive(true);
        }
        if (PlayerPrefs.GetFloat("volumeGame").IsBetween(0f, 1f)) // to use the same volume as in the previous game
        {
            SetVolume(PlayerPrefs.GetFloat("volumeGame"));
        }
        else
        {
            SetVolume(0.75f);
        }
        if (PlayerPrefs.GetFloat("SensibilityGame2").IsBetween(0f, 1f))// to use the same sensitivity as in the previous game
        {
            Setsensibility(PlayerPrefs.GetFloat("SensibilityGame2"));

        }
        else
        {
            Setsensibility(0.3f);
        }


        SwitchState(State.MENU);
    }
    // Function to switch between states
    public void SwitchState(State newState, float delay = 0.0f)
    {
        StartCoroutine(SwitchDelay(newState, delay));
    }
    // Function to switch between states
    IEnumerator SwitchDelay(State newState, float delay)
    {
        isSwitchingState = true;
        yield return new WaitForSeconds(delay);
        EndState();
        state = newState;
        BeginState(newState);
        isSwitchingState = false;
    }
    //sphere spawn with a delay that can be adjusted
    IEnumerator SpawnDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        Vector3 positionSphere = currentPlayer.transform.position + new Vector3(0, 1, 0);
        currentSphere = Instantiate(spherePrefab[Level], positionSphere, spherePrefab[Level].transform.rotation);
    }
    //sphere spawn with a delay that can be adjusted
    private void SpawnSphere(float delay = 1.0f)
    {
        StartCoroutine(SpawnDelay(delay));
    }
    // Things executed when entering a state
    void BeginState(State newState)
    {
        switch (newState)
        {
            case State.MENU:
                
                panelMenu.SetActive(true);
                textHighscore.text = "HIGHSCORE:" + PlayerPrefs.GetInt("HighscoreGame2");
                textCongratulation.SetActive(false);
                break;
            case State.INIT:
                panelPlay.SetActive(true);
                Score = 0;
                Level = 0;
                Right = 0;
                Wrong = 0;
                textSensibility.text = "SENSITIVITY: " + Sensibility + " %";
                Life = numberLife;
                if (currentLevel != null)
                {
                    Destroy(currentLevel);
                }
                SwitchState(State.LOADLEVEL);
                break;
            case State.PLAY:
                break;
            case State.LEVELCOMPLETED:
                Destroy(currentLevel);
                Destroy(currentPlayer);
                Destroy(currentWall);
                GameObject[] ball = GameObject.FindGameObjectsWithTag("Ball");
                for (int i = 0; i < ball.Length; i++)
                {
                    Destroy(ball[i]);
                }
                panelLevelCompleted.SetActive(true);
                Level++;
                SwitchState(State.LOADLEVEL, 2.0f);
                break;
            case State.LOADLEVEL:
                if (Level >= levels.Length)
                {
                    SwitchState(State.GAMEOVER);
                }
                else
                {
                    currentLevel = Instantiate(levels[Level]);
                    SwitchState(State.PLAY);
                }
                break;
            case State.GAMEOVER:
                textSensibility.text = "SENSITIVITY: " + Sensibility + " %";
                GameObject[] balll = GameObject.FindGameObjectsWithTag("Ball");
                for (int i = 0; i < balll.Length; i++)
                {
                    Destroy(balll[i]);
                }
                Destroy(currentLevel);
                Destroy(currentPlayer);
                Destroy(currentWall);
                panelGameOver.SetActive(true);
                panelPause.SetActive(true);
                if (Score > PlayerPrefs.GetInt("HighscoreGame2")) //save highscore 
                {
                    PlayerPrefs.SetInt("HighscoreGame2", Score);
                    textCongratulation.SetActive(true);
                }
                textFinalScore.text = "FINAL SCORE:" + Score;
                SwitchState(State.MENU, 5.0f);
                break;
            case State.PAUSE:
                Pause = 1;
                int f = 0;
                for (f = 0; f < LeapNopauseScene.Length; f++)
                {
                    LeapNopauseScene[f].SetActive(false);
                }
                for (f=0;f < pauseScene.Length;f++)
                {
                    pauseScene[f].SetActive(true);
                }
                panelPause.SetActive(true);

                break;

        }
    }

    void Update()
    {
        switch (state)
        {
            case State.MENU:
                break;
            case State.INIT:
                break;
            case State.PLAY:
                if (!hand.IsTracked)  //If the hand is not detected, pause the game.
                {
                    SwitchState(State.PAUSE);
                }


                if (currentPlayer == null)  //instantiate the player
                {
                    Vector3 position = new Vector3(-50, -17,- 0);
                    Quaternion rotation = Quaternion.EulerAngles(0, 0, 3.14f/2f);
                    currentPlayer = Instantiate(playerPrefab[Level + Offset], position, rotation);
                }

                if (currentSphere == null)  //instantiate the ball if the life > 0 else GameOver
                {
                    if (Life > 0)
                    {
                        SpawnSphere(2.0f);
                    }
                    else
                    {
                        SwitchState(State.GAMEOVER);
                    }
                }
                /*else
                {
                    StopCoroutine("SpawnDelay");
                }*/


                if (currentWall == null) //instantiate the wall in according of the level
                {
                    currentWall = Instantiate(wallPrefab[Level]);
                }
                
                if (currentLevel != null && currentLevel.transform.childCount == 0 && !isSwitchingState)
                {
                    SwitchState(State.LEVELCOMPLETED);
                }


                break;
            case State.LEVELCOMPLETED:
                break;
            case State.LOADLEVEL:
                break;
            case State.GAMEOVER:
                break;
            case State.PAUSE:
                if(pause.Equals(0))
                {
                    SwitchState(State.PLAY);
                }
                break;
        }
    }
    // Things done when exiting a state
    void EndState()
    {
        switch (state)
        {
            case State.MENU:
                panelMenu.SetActive(false);
                break;
            case State.INIT:
                break;
            case State.PLAY:
                break;
            case State.LEVELCOMPLETED:
                panelLevelCompleted.SetActive(false);
                break;
            case State.LOADLEVEL:
                break;
            case State.GAMEOVER:
                panelPlay.SetActive(false);
                panelGameOver.SetActive(false);
                panelPause.SetActive(false);
                break;
            case State.PAUSE:
                int i = 0;
                for (i = 0; i < pauseScene.Length; i++)
                {
                    pauseScene[i].SetActive(false);
                }
                int f = 0;
                for (f = 0; f < LeapNopauseScene.Length; f++)
                {
                    LeapNopauseScene[f].SetActive(true);
                }
                panelPause.SetActive(false);
                break;

        }
    }
}
