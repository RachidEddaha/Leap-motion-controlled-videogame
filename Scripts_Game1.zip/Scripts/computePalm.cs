using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity;
using Leap;
using Leap.Unity.Attributes;




public class computePalm : MonoBehaviour
{
    /** to calculate the orienattion of the palm and use it is value to controll the paddle**/
     

    private Pose Abd;
    public Vector3 position;
    public Quaternion orientation;
    public Vector3 inEUler;
    public float value4Controll = 0.0f;
    public float ExtremeValueLeft = -1.2f;
    public float ExtremeValueRight = 1f;
    private float ExtremeValueLeftCalculated = -1.2f;
    private float ExtremeValueRightCalculated = 1f;

    //The interval at which to check palm direction.
    [Units("seconds")]
    [Tooltip("The interval in seconds at which to check this detector's conditions.")]
    [MinValue(0)]
    public float Period = .1f; //seconds

    /**
         * The HandModelBase instance to observe. 
         * Set automatically if not explicitly set in the editor.
       */
    [Tooltip("The hand model to watch. Set automatically if detector is on a hand.")]
    public HandModelBase HandModel = null;

    private IEnumerator watcherCoroutine;

    private void Awake()
    {
        watcherCoroutine = palmWatcher();
        
    }

    private void OnEnable()
    {
        StartCoroutine(watcherCoroutine);
    }

    private void OnDisable()
    {
        StopCoroutine(watcherCoroutine);
      
    }

    /*this function allows you to adjust the sensitivity with which the movement of the hand is converted
    * into a command for the game by changing the extremes of the ranges of movement.
    * in this case we have the two extremes that we gradually decrease so that the amplitude of movement is reduced,
    * and we stop at a minimum value because otherwise it would be impossible to control 
    */
    public void SetSensibility(float percentage)  // to modifie the interval were you read the controller so to adjust the sensibility
    {
        ExtremeValueLeftCalculated = (ExtremeValueLeft-0.1f)*(1-percentage)+0.1f;
        ExtremeValueRightCalculated = (ExtremeValueRight-0.1f)*(1-percentage)+0.1f;
        GameManager.Sensibility = Mathf.RoundToInt(percentage * 100);
        print(percentage);
    }



    private IEnumerator palmWatcher()
    {
        Hand hand;
        Vector3 normal;
        /*
       * the sensitivity is initialized at zero, if it is not at zero it means that it has been
       * modified by the operator so the saved one is reused
       */
        if (GameManager.Sensibility==0)
        {
            SetSensibility(GameManager.Sensibility / 100); // because the sensibility has to be read to have it saved 
        }
        else
        {
            SetSensibility(0.3f);
        }
        

        value4Controll = 0;
        while (true)
        {
            if (HandModel != null) // if the leapmotion can read the hand 
            {
                hand = HandModel.GetLeapHand();
                if (hand != null)
                {
                    
                    Abd = hand.GetPalmPose();
                    position = Abd.position;
                    orientation = Abd.rotation;
                    inEUler = Quaternion.ToEulerAngles(orientation);

                    if (inEUler.z.IsBetween(-2.5f, -0.8f)) // we check if the palm is in the correct orientationl
                    {
                        /*
                         * with this formula we are going to change the range of values between those seen experimentally and the
                         * range -1 and 1 that serve as command for the helicopter
                         */
                        float value4Controll_1 = Mathf.Max((inEUler.y - ExtremeValueLeftCalculated) * 2 / (ExtremeValueRightCalculated - ExtremeValueLeftCalculated) - 1,-1); // to calculate the value controll  // y= (x-a)*(d-c)/(b-a)+c
                        value4Controll = Mathf.Min(value4Controll_1, 1);
                    }
                    
                }
            }
            yield return new WaitForSeconds(Period);// we wait for the period to have the new data setted at 0.012
        }
    }

}
