using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SphereMovement : MonoBehaviour
{
    #region Singleton
    private static SphereMovement _instance;
    public static SphereMovement Instance => _instance;

    private void Awake()
    {
        if (_instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;
        }
        
    }
    #endregion

    private Rigidbody ballRb;
    private float jumpForce = 25.0f;
    private float jumpForce1 = 30.0f;
    private float jumpForce2 = 35.0f;

    private float outOfBound = 20.0f;
    private Vector3 stopped = new Vector3(0, 0, 0);
    private Vector3 vel ;
    private Vector3 pos ;
    private int wasInPause = 0;
    private int condition;
    

    private Vector3 velocity;

    void Start()
    {
        ballRb = GetComponent<Rigidbody>();
        condition = 0;
        ballRb.velocity = Vector3.up * jumpForce;// togliere il jumpforce oppure mettere addForce
    }
    

    IEnumerator DestroyDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        Destroy(gameObject);
    }

    private void DestroySphere(float delay = 1.0f)
    {
        StartCoroutine(DestroyDelay(delay));
    }

    void Update()
    {
        /*if (Input.GetKeyDown(KeyCode.Space))
        {
            ballRb.velocity = Vector3.up * jumpForce;
        }*/
        //Destroy ball if his position is over outOfBound
        if(transform.position.y < -outOfBound)
        {
            DestroySphere(2f);           
        }
        if(transform.position.y < -outOfBound  && condition == 0) ////Life decrease if his position is over outOfBound
        {
            condition = 1;
            GameManager.Instance.Life--;
            GameManager.Instance.Wrong++;
        }
        if (GameManager.Pause.Equals(1))
        {
            if(ballRb.velocity != stopped)
            {
                 vel = ballRb.velocity;
                 pos = ballRb.position;
                 jumpForce = 0f;
            }
            ballRb.velocity = stopped;
            ballRb.position = pos;
            wasInPause = 1;
           
        }
        if (GameManager.Pause.Equals(0) && wasInPause.Equals(1))
        {

            jumpForce = 25f;
            ballRb.velocity = vel;
            wasInPause = 0;

        }

    }
    //SEt the velocity of the ball for each Level
    void FixedUpdate()
    {
        if(GameManager.Instance.Level == 0)
        {
            ballRb.velocity = ballRb.velocity.normalized * jumpForce;
            velocity = ballRb.velocity;
        } else if (GameManager.Instance.Level == 1)
        {
            ballRb.velocity = ballRb.velocity.normalized * jumpForce1;
            velocity = ballRb.velocity;
        } else
        {
            ballRb.velocity = ballRb.velocity.normalized * jumpForce2;
            velocity = ballRb.velocity;
        }
        
    }
    //When the ball collide with other RigidBody his velocity is reflect respect to the normal of the object
    private void OnCollisionEnter(Collision coll)
    {
        ballRb.velocity = Vector3.Reflect(velocity, coll.GetContact(0).normal);
       
    }
}
