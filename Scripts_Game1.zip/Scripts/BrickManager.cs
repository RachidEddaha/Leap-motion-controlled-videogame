using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrickManager : MonoBehaviour
{
    private int life = 1;
    private int score = 3;
    private Vector3 rotator = new Vector3(60, 0, 0);
    AudioSource audioo;
    

    void Start()
    {
        transform.Rotate(rotator * (transform.position.x + transform.position.y) * 0.2f);
        audioo = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(rotator * Time.deltaTime);
    }
    //Destroy brik when collide with the ball
    private void OnCollisionEnter(Collision coll)
    {
        audioo.Play();
        life--;
        if (life <= 0)
        {
            Destroy(gameObject,0.5f);
            gameObject.layer = 6;
            GameManager.Instance.Score += score;
        }
       
    }
}

